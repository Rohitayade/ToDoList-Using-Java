package todolist;

public class AddTask extends ToDoList{

	public static void addTask() {

		System.out.println("Enter the task: ");
		String task = sc.nextLine();
		tasks.add(task);
		System.out.println("Task Added!!");

	}

}
