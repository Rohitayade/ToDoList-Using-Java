package todolist;

public class MarkTaskAsCompleted extends ToDoList {

	public static void markAsCompleted() {

		ViewTask.viewTask();
		if (!tasks.isEmpty()) {

			System.out.println("Enter the task.no you want to mark as complete: ");
			int q = sc.nextInt();
			sc.nextLine();
			if (q > 0 && q <= tasks.size()) {
				String ss = tasks.get(q - 1) + " (Completed)";
				tasks.set(q - 1, ss);
				System.out.println("Succesfully marked the task as completed!");
			} else {
				System.out.println("Invalid task.no, please try again!");
			}

		}
	}

}
