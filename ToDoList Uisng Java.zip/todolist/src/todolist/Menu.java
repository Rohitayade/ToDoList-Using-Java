package todolist;

public class Menu extends ToDoList {

	public static void printMenu() {
		
		System.out.println("The To-Do-List Application");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("1. Add a task");
		System.out.println("2. View the tasks");
		System.out.println("3. Remove particular task");
		System.out.println("4. Mark task as Completed");
		System.out.println("5. Exit the To-Do-List");
		System.out.println("-----------------------------------------------------------------");
		System.out.println("Enter your choice: ");
		
	}
}
