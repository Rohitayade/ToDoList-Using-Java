package todolist;

public class RemoveTask extends ToDoList {

	public static void removeTask() {

		ViewTask.viewTask();
		if (!tasks.isEmpty()) {
			System.out.println("Enter the task you want to delete: ");
			int x = sc.nextInt();
			sc.nextLine();
			if (x > 0 && x <= tasks.size()) {
				tasks.remove(x - 1);
				System.out.println("Task removed successfully");
			} else {
				System.out.println("Invalid task number, try again!");
			}
		}

	}

}
