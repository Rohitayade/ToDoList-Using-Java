package todolist;

import java.util.*;
import java.util.Scanner;

public class ToDoList {

	protected static ArrayList<String> tasks = new ArrayList<>();
	protected static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		Boolean running = true;

		while (running) {

			Menu.printMenu();
			int choice = sc.nextInt();
			sc.nextLine();

			switch (choice) {

			case 1:
				AddTask.addTask();
				break;

			case 2:
				ViewTask.viewTask();
				break;

			case 3:
				RemoveTask.removeTask();
				break;

			case 4:
				MarkTaskAsCompleted.markAsCompleted();
				break;

			case 5:
				running = false;
				break;

			default:
				System.out.println("Invalid option, try again!");

			}

		}

		System.out.println("Exiting the To-Do-list, Bye!");
		sc.close();
	}

}
