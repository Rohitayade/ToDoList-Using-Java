package todolist;


public class ViewTask extends ToDoList {

	public static void viewTask() {

		if (tasks.isEmpty()) {
			System.out.println("No tasks to display");
		} else {
			System.out.println("To-Do-List Tasks are- ");
			for (int i = 0; i < tasks.size(); i++) {
				System.out.println((i + 1) + ". " + tasks.get(i));
			}

		}
	}

}
